<div id="label-page"><h3>Beranda</h3></div>
<div id="content">
	<div id="beranda-judul">
		<h1>SELAMAT DATANG DI SISTEM INFORMASI PERPUSTAKAAN</h1>
	</div>
	<div id="beranda-konten">
		<h2> "MEMBACA ADALAH JENDELA DUNIA" </h2>
	</div>
</div>